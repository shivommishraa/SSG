<?php
/**
 * WooCommerce - Quick View Modal
 *
 */

?>
<div class="thnk-quick-view-bg"><div class="thnk-quick-view-loader blockOverlay">

</div></div>
<div id="thnk-quick-view-modal">
	<div class="thnk-content-main-wrapper"><?php ;/*Don't remove this html comment*/ ?><!--
	--><div class="thnk-content-main">
			<div class="thnk-lightbox-content">
				<div class="thnk-content-main-head">
					<a href="#" id="thnk-quick-view-close" class="thnk-quick-view-close-btn"></a>
				</div>
				<div id="thnk-quick-view-content" class="woocommerce single-product"></div>
			</div>
		</div>
	</div>
</div>